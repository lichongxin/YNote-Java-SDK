/**
 * Fundamental classes and algorithms for implementing <a href="http://oauth.net/">OAuth</a>.
 */
package net.oauth;
