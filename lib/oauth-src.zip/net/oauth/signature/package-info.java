/**
 * Classes to compute and verify digital signatures.
 */
package net.oauth.signature;
